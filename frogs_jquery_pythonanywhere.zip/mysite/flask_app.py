
# A very simple Flask Hello World app for you to get started with...

from flask import Flask, render_template # flask.py -> class Flask

app = Flask(__name__) # Instantiating the object that implements all the HTTP comunication

@app.route('/')
def index():
    return render_template("index.html")

@app.route('/frogs_jquery')
def frogs_jquery():
    return render_template("index_jquery.html")
